import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Campusevents extends StatelessWidget {
  const Campusevents({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: BoxDecoration(
              color: Color.fromRGBO(12, 45, 112, 1.00),
              borderRadius: BorderRadius.all(Radius.circular(00))),
        ),
        centerTitle: true,
        title: Text(
          'LIFE AT BCAS CAMPUS',
          style: GoogleFonts.kanit(fontSize: 25),
        ),
      ),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              SizedBox(
                height: 20.0,
              ),
              Container(
                  width: 380,
                  color: const Color.fromARGB(255, 255, 255, 255),
                  child: Column(
                    children: [
                      Image(
                        image: AssetImage('assets/images/BM.jpg'),
                        fit: BoxFit.cover,
                      ),
                      Text('Bio Medical Laboratory',
                          style: GoogleFonts.kanit(
                              fontSize: 25,
                              color: Color.fromARGB(255, 0, 0, 0))),
                    ],
                  )),
              SizedBox(
                height: 20.0,
              ),
              Container(
                  width: 380,
                  color: const Color.fromARGB(255, 255, 255, 255),
                  child: Column(
                    children: [
                      Image(
                        image: AssetImage('assets/images/CL1.jpg'),
                        fit: BoxFit.cover,
                      ),
                      Text('Computer Laboratory',
                          style: GoogleFonts.kanit(
                              fontSize: 25,
                              color: Color.fromARGB(255, 0, 0, 0))),
                    ],
                  )),
              SizedBox(
                height: 20.0,
              ),
              Container(
                  width: 380,
                  color: const Color.fromARGB(255, 255, 255, 255),
                  child: Column(
                    children: [
                      Image(
                        image: AssetImage('assets/images/CL2.jpg'),
                        fit: BoxFit.cover,
                      ),
                      Text('Additional Computer laboratory',
                          style: GoogleFonts.kanit(
                              fontSize: 25,
                              color: Color.fromARGB(255, 0, 0, 0))),
                    ],
                  )),
              SizedBox(
                height: 20.0,
              ),
              Container(
                  width: 380,
                  color: const Color.fromARGB(255, 255, 255, 255),
                  child: Column(
                    children: [
                      Image(
                        image: AssetImage('assets/images/LB.jpg'),
                        fit: BoxFit.cover,
                      ),
                      Text('Library',
                          style: GoogleFonts.kanit(
                              fontSize: 25,
                              color: Color.fromARGB(255, 0, 0, 0))),
                    ],
                  )),
              SizedBox(
                height: 20.0,
              ),
              Container(
                  width: 380,
                  color: const Color.fromARGB(255, 255, 255, 255),
                  child: Column(
                    children: [
                      Image(
                        image: AssetImage('assets/images/RB.jpg'),
                        fit: BoxFit.cover,
                      ),
                      Text('Reaseach & Development',
                          style: GoogleFonts.kanit(
                              fontSize: 25,
                              color: Color.fromARGB(255, 0, 0, 0))),
                    ],
                  )),
              SizedBox(
                height: 20.0,
              ),
              Container(
                  width: 380,
                  color: const Color.fromARGB(255, 255, 255, 255),
                  child: Column(
                    children: [
                      Image(
                        image: AssetImage('assets/images/CT.jpg'),
                        fit: BoxFit.cover,
                      ),
                      Text('Cafetaria',
                          style: GoogleFonts.kanit(
                              fontSize: 25,
                              color: Color.fromARGB(255, 0, 0, 0))),
                    ],
                  )),
              SizedBox(
                height: 20.0,
              ),
              Container(
                  width: 380,
                  color: const Color.fromARGB(255, 255, 255, 255),
                  child: Column(
                    children: [
                      Image(
                        image: AssetImage('assets/images/DC.jpg'),
                        fit: BoxFit.cover,
                      ),
                      Text('Study Area',
                          style: GoogleFonts.kanit(
                              fontSize: 25,
                              color: Color.fromARGB(255, 0, 0, 0))),
                    ],
                  )),
              SizedBox(
                height: 11.0,
              ),
              Container(
                height: 250,
                width: 450,
                color: Color.fromRGBO(45, 45, 45, 1.00),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      height: 250,
                      width: 300,
                      child: Image(image: AssetImage('assets/images/bcas.png')),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
