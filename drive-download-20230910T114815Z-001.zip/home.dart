import 'dart:io';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/material.dart';
import 'package:bcas_app/drawer/aboutus.dart';
import 'package:bcas_app/drawer/award.dart';
import 'package:bcas_app/drawer/event.dart';
// import 'package:bcas_app/drawer/result.dart';
import 'package:bcas_app/drawer/clubs.dart';
import 'package:bcas_app/drawer/lecturing.dart';
import 'package:bcas_app/courses/networking.dart';
import 'package:bcas_app/courses/software.dart';
import 'package:bcas_app/drawer/login/login.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
// import "package:hovering/hovering.dart";
import 'Drawer/location.dart';

class MyApp extends StatefulWidget {
  const MyApp({super.key, required title});

  Future<void> _launchURL(String url) async {
    final Uri uri = Uri(scheme: "https", host: url);
    if (!await launchUrl(
      uri,
      mode: LaunchMode.externalApplication,
    )) {
      throw "Can not launch url";
    }
  }

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,

      //App Bar

      appBar: AppBar(
        toolbarHeight: 90,
        actions: [
          IconButton(
            onPressed: () {
              if (Platform.isAndroid) {
                SystemNavigator.pop();
              }
            },
            icon: const Icon(Icons.exit_to_app_outlined),
          )
        ],
        elevation: 0,
        backgroundColor: Colors.transparent,
        title: Text(
          'BCAS COMPUTING',
          style: GoogleFonts.kanit(fontSize: 25),
        ),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: BoxDecoration(
              color: Color.fromRGBO(12, 45, 112, 1.00),
              borderRadius: BorderRadius.all(Radius.circular(0))),
        ),
      ),
      backgroundColor: Color.fromRGBO(255, 255, 255, 1),
      body: SingleChildScrollView(
        // Networking & Software Pages

        child: Center(
          child: Column(
            children: [
              // Row(),
              SizedBox(
                height: 140.0,
              ),

              GestureDetector(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const Networking()));
                },
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Column(
                    children: [
                      Container(
                        height: 250,
                        width: 380,
                        child: Container(
                          height: 250,
                          width: 380,
                          color: Color.fromARGB(255, 255, 255, 255),
                          child: Image(
                            image: AssetImage('assets/images/networking.jpg'),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      Container(
                        // height: 220,
                        width: 380,
                        color: Color.fromRGBO(131, 1, 14, 1),
                        padding: EdgeInsets.all(15),
                        child: Text(
                          textAlign: TextAlign.center,
                          'EXPLORE MORE',
                          style: GoogleFonts.kanit(
                              fontSize: 20, color: Colors.white),
                          maxLines: 25,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 30.0,
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const Software()));
                },
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Column(
                    children: [
                      Container(
                          height: 250,
                          width: 380,
                          color: Colors.white,
                          child: Image(
                            image: AssetImage('assets/images/softwaree.jpg'),
                            fit: BoxFit.cover,
                          )),
                      Container(
                        // height: 220,
                        width: 380,
                        color: Color.fromRGBO(131, 1, 14, 1),
                        padding: EdgeInsets.all(15),
                        child: Text(
                          textAlign: TextAlign.center,
                          'EXPLORE MORE',
                          style: GoogleFonts.kanit(
                              fontSize: 20, color: Colors.white),
                          maxLines: 25,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              //Acagemic Partners

              // SizedBox(
              //   height: 60.0,
              // ),
              Divider(
                height: 100,
                color: Color.fromRGBO(131, 1, 14, 1),
                thickness: 1.5,
                indent: 10,
                endIndent: 10,
              ),
              Container(
                child: Text(
                  'Academic Partners',
                  style: GoogleFonts.kanit(
                      fontSize: 25, fontWeight: FontWeight.bold),
                ),
              ),
              SizedBox(
                height: 25,
              ),

              Container(
                height: 100,

                //Partners Logo 1

                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      height: 200.0,
                    ),
                    SizedBox(
                      height: 20.0,
                    ),
                    Container(
                      height: 85,
                      width: 150,
                      color: Color.fromARGB(255, 252, 252, 252),
                      child:
                          Image(image: AssetImage('assets/curosal/oxford.png')),
                    ),
                    SizedBox(
                      width: 20.0,
                    ),
                    Container(
                      height: 85,
                      width: 150,
                      color: Color.fromARGB(255, 255, 255, 255),
                      child:
                          Image(image: AssetImage('assets/curosal/solent.png')),
                    ),
                  ],
                ),
              ),

              //Partners Logo 2

              SizedBox(
                height: 30.0,
              ),
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: 85,
                      width: 150,
                      color: Color.fromARGB(255, 255, 255, 255),
                      child:
                          Image(image: AssetImage('assets/curosal/tvec.png')),
                    ),
                    SizedBox(
                      width: 20.0,
                    ),
                    Container(
                      height: 85,
                      width: 150,
                      color: Color.fromARGB(255, 255, 255, 255),
                      child: Image(image: AssetImage('assets/curosal/ugc.png')),
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 30.0,
              ),
              //Partner logo 3
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: 85,
                      width: 150,
                      color: Color.fromARGB(255, 255, 255, 255),
                      child: Image(
                          image: AssetImage('assets/curosal/pearson.png')),
                    ),
                  ],
                ),
              ),
              Divider(
                height: 100,
                color: Color.fromRGBO(131, 1, 14, 1),
                thickness: 1.5,
                indent: 10,
                endIndent: 10,
              ),
              Container(
                child: Text(
                  'Media',
                  style: GoogleFonts.kanit(
                      fontSize: 25, fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(
                height: 15,
              ),

              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    height: 320,
                    width: 410,
                    color: const Color.fromARGB(255, 255, 255, 255),
                    child: Column(
                      children: [
                        IconButton(
                          iconSize: 40,
                          icon: const Icon(Icons.facebook),
                          onPressed: () async {
                            const url = 'https://blog.logrocket.com';
                            if (await canLaunch(url)) {
                              await launch(url);
                            } else {
                              throw 'Could not launch $url';
                            }
                          },
                        ),
                        Text('Facebook',
                            style: GoogleFonts.kanit(fontSize: 18)),
                        SizedBox(
                          height: 10.0,
                        ),
                        IconButton(
                          iconSize: 40,
                          icon: const Icon(Icons.mail),
                          onPressed: () async {
                            dynamic launchEmail() async {
                              try {
                                Uri email = Uri(
                                  scheme: 'mailto',
                                  path: "abcd@gmail.com",
                                  queryParameters: {
                                    'subject': "Testing subject"
                                  },
                                );

                                await launchUrl(email);
                              } catch (e) {
                                debugPrint(e.toString());
                              }
                            }
                          },
                        ),
                        Text('Mail', style: GoogleFonts.kanit(fontSize: 18)),
                        SizedBox(
                          height: 10.0,
                        ),
                        IconButton(
                          iconSize: 40,
                          icon: const Icon(Icons.phone),
                          onPressed: () async {
                            final url = Uri.parse('tel:+94 778 444 555');
                            if (await canLaunchUrl(url)) {
                              launchUrl(url);
                            } else {
                              // ignore: avoid_print
                              print("Can't launch $url");
                            }
                          },
                        ),
                        Text('Contect Number',
                            style: GoogleFonts.kanit(fontSize: 18)),
                        SizedBox(
                          height: 10.0,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 25,
              ),
              Container(
                height: 400,
                width: 450,
                color: Color.fromRGBO(45, 45, 45, 1.00),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      height: 250,
                      width: 300,
                      child: Image(image: AssetImage('assets/images/bcas.png')),
                    ),
                    SizedBox(
                      height: 10.0,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Text('COLOMBO',
                            style: GoogleFonts.kanit(
                              fontSize: 22,
                              color: Color.fromRGBO(131, 1, 14, 1),
                            )),
                        Text('KANDY',
                            style: GoogleFonts.kanit(
                              fontSize: 22,
                              color: Color.fromRGBO(131, 1, 14, 1),
                            )),
                        Text('KALMUNAI',
                            style: GoogleFonts.kanit(
                              fontSize: 22,
                              color: Color.fromRGBO(131, 1, 14, 1),
                            ))
                      ],
                    ),
                    SizedBox(
                      height: 25.0,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Text('JAFFNA',
                            style: GoogleFonts.kanit(
                              fontSize: 22,
                              color: Color.fromRGBO(131, 1, 14, 1),
                            )),
                        Text('GALLE',
                            style: GoogleFonts.kanit(
                              fontSize: 22,
                              color: Color.fromRGBO(131, 1, 14, 1),
                            )),
                      ],
                    ),
                    SizedBox(
                      height: 13.0,
                    ),
                    Divider(
                      height: 2,
                      color: Color.fromRGBO(131, 1, 14, 1),
                      thickness: 1.5,
                      indent: 70,
                      endIndent: 70,
                    ),
                    SizedBox(
                      height: 11.0,
                    ),
                    Text('Concept, Design & Development by TECH GURU - CSD 16',
                        style: GoogleFonts.kanit(
                            fontSize: 12,
                            color: Color.fromRGBO(255, 255, 255, 1)))
                  ],
                ),
              )
            ],
          ),
        ),
      ),

      drawer: Drawer(
        child: Container(
          color: const Color.fromARGB(255, 255, 255, 255),
          child: ListView(
            children: [
              DrawerHeader(
                  child: Image(
                image: AssetImage('assets/images/bcasnm.png'),
                fit: BoxFit.contain,
              )),
              ListTile(
                title: const Text(
                  'About Us',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                ),
                leading: const Icon(
                  Icons.info,
                  size: 25,
                  color: Color.fromRGBO(0, 45, 112, 1.00),
                ),
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => const Aboutus()));
                },
              ),
              const Divider(
                height: 0.2,
                color: Color.fromRGBO(131, 1, 14, 1),
                indent: 10,
                endIndent: 10,
              ),
              ListTile(
                title: const Text(
                  'Results',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                ),
                leading: const Icon(
                  Icons.analytics,
                  size: 25,
                  color: Color.fromRGBO(0, 45, 112, 1.00),
                ),
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Login()));
                },
              ),
              const Divider(
                height: 0.2,
                color: Color.fromRGBO(131, 1, 14, 1),
                indent: 10,
                endIndent: 10,
              ),
              // const Divider(
              //   height: 0.2,
              // ),
              ListTile(
                title: const Text(
                  'Life at BCAS',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                ),
                leading: const Icon(
                  Icons.event,
                  size: 25,
                  color: Color.fromRGBO(0, 45, 112, 1.00),
                ),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const Campusevents()));
                },
              ),
              const Divider(
                height: 0.2,
                color: Color.fromRGBO(131, 1, 14, 1),
                indent: 10,
                endIndent: 10,
              ),
              ListTile(
                title: Text(
                  'Location',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                ),
                leading: Icon(
                  Icons.location_on_outlined,
                  size: 25,
                  color: Color.fromRGBO(0, 45, 112, 1.00),
                ),
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Location()));
                },
              ),
              const Divider(
                height: 0.2,
                color: Color.fromRGBO(131, 1, 14, 1),
                indent: 10,
                endIndent: 10,
              ),
              ListTile(
                title: const Text(
                  'Our Lecturers',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                ),
                leading: const Icon(
                  Icons.people_outline,
                  size: 25,
                  color: Color.fromRGBO(0, 45, 112, 1.00),
                ),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const Lecturing()));
                },
              ),
              const Divider(
                height: 0.2,
                color: Color.fromRGBO(131, 1, 14, 1),
                indent: 10,
                endIndent: 10,
              ),
              ListTile(
                title: const Text(
                  'Awards',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                ),
                leading: const Icon(
                  Icons.star,
                  size: 25,
                  color: Color.fromRGBO(0, 45, 112, 1.00),
                ),
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => const Awards()));
                },
              ),
              const Divider(
                height: 0.2,
                color: Color.fromRGBO(131, 1, 14, 1),
                indent: 10,
                endIndent: 10,
              ),

              ListTile(
                title: const Text(
                  'Clubs',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                ),
                leading: const Icon(
                  Icons.groups_outlined,
                  size: 25,
                  color: Color.fromRGBO(0, 45, 112, 1.00),
                ),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const Campusclubs()));
                },
              ),
              const Divider(
                height: 0.2,
                color: Color.fromRGBO(131, 1, 14, 1),
                indent: 10,
                endIndent: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
