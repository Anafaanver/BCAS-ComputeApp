import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Lecturing extends StatelessWidget {
  const Lecturing({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          toolbarHeight: 70,
          elevation: 0,
          backgroundColor: Colors.transparent,
          title: Text(
            'Our Lecturers',
            style: GoogleFonts.kanit(fontSize: 25, fontWeight: FontWeight.bold),
          ),
          centerTitle: true,
          flexibleSpace: Container(
            decoration: BoxDecoration(
                color: Color.fromRGBO(12, 45, 112, 1.00),
                borderRadius: BorderRadius.all(Radius.circular(20))),
          ),
        ),
        backgroundColor: Color.fromRGBO(255, 255, 255, 1.00),
        body: SingleChildScrollView(
          
        ));
  }
}
