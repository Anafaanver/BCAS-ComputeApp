import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Awards extends StatelessWidget {
  const Awards({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: BoxDecoration(
              color: Color.fromRGBO(12, 45, 112, 1.00),
              borderRadius: BorderRadius.all(Radius.circular(00))),
        ),
        centerTitle: true,
        title: Text(
          'AWARDS',
          style: GoogleFonts.kanit(fontSize: 25),
        ),
      ),
      backgroundColor: Color.fromRGBO(255, 255, 255, 1.00),
      body: SingleChildScrollView(
          child: Column(children: [
        SizedBox(
          height: 40.0,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              height: 200,
              width: 160,
              color: const Color.fromARGB(255, 255, 255, 255),
              child: Column(
                children: [
                  Image(
                    image: AssetImage('assets/images/A4.jpg'),
                    fit: BoxFit.cover,
                  ),
                  Text('BTEC Award',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0))),
                  Text('2010',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0)))
                ],
              ),
            ),
            Container(
              height: 200,
              width: 160,
              color: const Color.fromARGB(255, 255, 255, 255),
              child: Column(
                children: [
                  Image(
                    image: AssetImage('assets/images/A5.jpg'),
                    fit: BoxFit.cover,
                  ),
                  Text('BTEC Award',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0))),
                  Text('2011',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0)))
                ],
              ),
            ),
          ],
        ),
        SizedBox(
          height: 20.0,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              height: 200,
              width: 160,
              color: const Color.fromARGB(255, 255, 255, 255),
              child: Column(
                children: [
                  Image(
                    image: AssetImage('assets/images/A6.jpg'),
                    fit: BoxFit.cover,
                  ),
                  Text('BTEC Gold Award',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0))),
                  Text('2013',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0)))
                ],
              ),
            ),
            Container(
              height: 200,
              width: 160,
              color: const Color.fromARGB(255, 255, 255, 255),
              child: Column(
                children: [
                  Image(
                    image: AssetImage('assets/images/A15.jpg'),
                    fit: BoxFit.cover,
                  ),
                  Text('Ranked No1 Higher Edu',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0))),
                  Text('2014',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0)))
                ],
              ),
            ),
          ],
        ),
        SizedBox(
          height: 20.0,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              height: 200,
              width: 160,
              color: const Color.fromARGB(255, 255, 255, 255),
              child: Column(
                children: [
                  Image(
                    image: AssetImage('assets/images/A1.jpg'),
                    fit: BoxFit.cover,
                  ),
                  Text('Academic Impact Winner',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0))),
                  Text('2016',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0)))
                ],
              ),
            ),
            Container(
              height: 200,
              width: 160,
              color: const Color.fromARGB(255, 255, 255, 255),
              child: Column(
                children: [
                  Image(
                    image: AssetImage('assets/images/A13.jpg'),
                    fit: BoxFit.cover,
                  ),
                  Text('Platinum Partner No1',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0))),
                  Text('2016',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0)))
                ],
              ),
            ),
          ],
        ),
        SizedBox(
          height: 20.0,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              height: 200,
              width: 160,
              color: const Color.fromARGB(255, 255, 255, 255),
              child: Column(
                children: [
                  Image(
                    image: AssetImage('assets/images/A16.jpg'),
                    fit: BoxFit.cover,
                  ),
                  Text('Visionary Leadership',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0))),
                  Text('2016',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0)))
                ],
              ),
            ),
            Container(
              height: 200,
              width: 160,
              color: const Color.fromARGB(255, 255, 255, 255),
              child: Column(
                children: [
                  Image(
                    image: AssetImage('assets/images/A14.jpg'),
                    fit: BoxFit.cover,
                  ),
                  Text('Platinum Partner No1',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0))),
                  Text('2017',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0)))
                ],
              ),
            ),
          ],
        ),
        //phase 2
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              height: 200,
              width: 160,
              color: const Color.fromARGB(255, 255, 255, 255),
              child: Column(
                children: [
                  Image(
                    image: AssetImage('assets/images/A2.jpg'),
                    fit: BoxFit.cover,
                  ),
                  Text('Best Employer Brand',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0))),
                  Text('2017',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0)))
                ],
              ),
            ),
            Container(
              height: 200,
              width: 160,
              color: const Color.fromARGB(255, 255, 255, 255),
              child: Column(
                children: [
                  Image(
                    image: AssetImage('assets/images/A9.jpg'),
                    fit: BoxFit.cover,
                  ),
                  Text('Gold Award Pearson',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0))),
                  Text('2017',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0)))
                ],
              ),
            ),
          ],
        ),
        SizedBox(
          height: 20.0,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              height: 200,
              width: 160,
              color: const Color.fromARGB(255, 255, 255, 255),
              child: Column(
                children: [
                  Image(
                    image: AssetImage('assets/images/A12.jpg'),
                    fit: BoxFit.cover,
                  ),
                  Text('Outstanding Contribution',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0))),
                  Text('2018',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0)))
                ],
              ),
            ),
            Container(
              height: 200,
              width: 160,
              color: const Color.fromARGB(255, 255, 255, 255),
              child: Column(
                children: [
                  Image(
                    image: AssetImage('assets/images/A7.jpg'),
                    fit: BoxFit.cover,
                  ),
                  Text('BTEC Gold Award',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0))),
                  Text('2018',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0)))
                ],
              ),
            ),
          ],
        ),
        SizedBox(
          height: 20.0,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              height: 200,
              width: 160,
              color: const Color.fromARGB(255, 255, 255, 255),
              child: Column(
                children: [
                  Image(
                    image: AssetImage('assets/images/A8.jpg'),
                    fit: BoxFit.cover,
                  ),
                  Text('Excellence in Training',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0))),
                  Text('2018',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0)))
                ],
              ),
            ),
            Container(
              height: 200,
              width: 160,
              color: const Color.fromARGB(255, 255, 255, 255),
              child: Column(
                children: [
                  Image(
                    image: AssetImage('assets/images/A3.jpg'),
                    fit: BoxFit.cover,
                  ),
                  Text('Best Employer Brand',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0))),
                  Text('2018',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0)))
                ],
              ),
            ),
          ],
        ),
        SizedBox(
          height: 20.0,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              height: 200,
              width: 160,
              color: const Color.fromARGB(255, 255, 255, 255),
              child: Column(
                children: [
                  Image(
                    image: AssetImage('assets/images/A11.jpg'),
                    fit: BoxFit.cover,
                  ),
                  Text('Gold Award – Pearson UK',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0))),
                  Text('2019',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0)))
                ],
              ),
            ),
            Container(
              height: 200,
              width: 160,
              color: const Color.fromARGB(255, 255, 255, 255),
              child: Column(
                children: [
                  Image(
                    image: AssetImage('assets/images/A10.jpg'),
                    fit: BoxFit.cover,
                  ),
                  Text('Gold Award – Pearson UK',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0))),
                  Text('2020',
                      style: GoogleFonts.kanit(
                          fontSize: 15, color: Color.fromARGB(255, 0, 0, 0)))
                ],
              ),
            ),
          ],
        ),
        SizedBox(
          height: 50.0,
        ),
        Container(
          height: 250,
          width: 450,
          color: Color.fromRGBO(45, 45, 45, 1.00),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                height: 250,
                width: 300,
                child: Image(image: AssetImage('assets/images/bcas.png')),
              ),
            ],
          ),
        )
      ])),
    );
  }
}
