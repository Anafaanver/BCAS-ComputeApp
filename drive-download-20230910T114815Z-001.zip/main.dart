import 'package:bcas_app/Drawer/result.dart';
import 'package:flutter/material.dart';
import 'package:bcas_app/splash.dart';

void main() {
  runApp(const MaterialApp(home: Splashscreen()));
}

class BcasApp extends StatelessWidget {
  const BcasApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BCAS Computing',
      home: Splashscreen(),
      routes: {
        '/result': (context) => new Results(),
        '/Splashscreen': (context) => new Splashscreen(),
      },
    );
  }
}
