import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Campusclubs extends StatelessWidget {
  const Campusclubs({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: BoxDecoration(
              color: Color.fromRGBO(12, 45, 112, 1.00),
              borderRadius: BorderRadius.all(Radius.circular(00))),
        ),
        centerTitle: true,
        title: Text(
          'CLUBS',
          style: GoogleFonts.kanit(fontSize: 25),
        ),
      ),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              SizedBox(
                height: 20.0,
              ),
              Container(
                width: 380,
                color: Color.fromRGBO(12, 45, 112, 1),
                padding: EdgeInsets.all(15),
                child: Text(
                  textAlign: TextAlign.center,
                  'BCAS Information Technology Society (BITS)',
                  style: GoogleFonts.kanit(fontSize: 20, color: Colors.white),
                  maxLines: 25,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              SizedBox(
                height: 10.0,
              ),
              Container(
                height: 200,
                color: const Color.fromARGB(255, 255, 255, 255),
                child: Image(image: AssetImage('assets/images/bits.jpg')),
              ),
              SizedBox(
                height: 10.0,
              ),
              Text(
                'BITS',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
              ),
              SizedBox(
                height: 11.0,
              ),
              Container(
                height: 340,
                width: 380,
                color: Color.fromRGBO(131, 1, 14, 1),
                padding: EdgeInsets.all(15),
                child: Text(
                  textAlign: TextAlign.center,
                  'The BCAS Campus IT Society, a vibrant community dedicated to exploring the exciting realms of technology. Goal is simple yet ambitious: to foster a collaborative environment where fellow enthusiasts like you can delve into the fascinating domains of software, networking, and security. We believe that by coming together, sharing knowledge, and learning from each others experiences, we can unlock a world of possibilities. Our vision for the BCAS Campus IT Society is to create a platform where every member, regardless of their English proficiency, can comfortably engage in discussions, workshops, and projects. Together, well navigate the dynamic world of IT, foster valuable connections, and develop skills that will undoubtedly shape our futures.',
                  style: GoogleFonts.kanit(fontSize: 15, color: Colors.white),
                  maxLines: 25,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Divider(
                height: 100,
                color: Color.fromRGBO(131, 1, 14, 1),
                thickness: 1.5,
                indent: 10,
                endIndent: 10,
              ),
              Container(
                width: 380,
                color: Color.fromRGBO(12, 45, 112, 1),
                padding: EdgeInsets.all(15),
                child: Text(
                  textAlign: TextAlign.center,
                  'BCAS English Language Society (BELS)',
                  style: GoogleFonts.kanit(fontSize: 20, color: Colors.white),
                  maxLines: 25,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              SizedBox(
                height: 10.0,
              ),
              Container(
                height: 200,
                color: const Color.fromARGB(255, 255, 255, 255),
                child: Image(image: AssetImage('assets/images/bels.jpg')),
              ),
              SizedBox(
                height: 10.0,
              ),
              Text(
                'BELS',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
              ),
              SizedBox(
                height: 11.0,
              ),
              Container(
                height: 200,
                width: 380,
                color: Color.fromRGBO(131, 1, 14, 1),
                padding: EdgeInsets.all(15),
                child: Text(
                  textAlign: TextAlign.center,
                  'The inauguration of BCAS English Language Society (BELS) organized by British College of Applied Studies was held on 13th September 2022. The CEO Dr. Susil Kumar graced the occasion as the Chief Guest and encouraged the enthusiastic newly appointed team. It was attended by COO, the senior management, all the Heads of Schools, Senior lecturers and students. Masters Club',
                  style: GoogleFonts.kanit(fontSize: 15, color: Colors.white),
                  maxLines: 25,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Divider(
                height: 100,
                color: Color.fromRGBO(131, 1, 14, 1),
                thickness: 1.5,
                indent: 10,
                endIndent: 10,
              ),
              SizedBox(
                height: 11.0,
              ),
              Container(
                height: 250,
                width: 450,
                color: Color.fromRGBO(45, 45, 45, 1.00),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      height: 250,
                      width: 300,
                      child: Image(image: AssetImage('assets/images/bcas.png')),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
