import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';

class Networking extends StatelessWidget {
  const Networking({super.key});

  Future<void> _launchURL(String url) async {
    final Uri uri = Uri(scheme: "https", host: url);
    if (!await launchUrl(
      uri,
      mode: LaunchMode.externalApplication,
    )) {
      throw "Can not launch url";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: BoxDecoration(
              color: Color.fromRGBO(12, 45, 112, 1.00),
              borderRadius: BorderRadius.all(Radius.circular(00))),
        ),
        centerTitle: true,
        title: Text(
          'NETWORK',
          style: GoogleFonts.kanit(fontSize: 25),
        ),
      ),

      backgroundColor: Color.fromRGBO(255, 255, 255, 1.00),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(10, 100, 10, 50),
                color: Color.fromRGBO(131, 1, 14, 1),
                width: 380,
                height: 500,
                child: Column(
                  children: [
                    SizedBox(
                      height: 50.0,
                    ),
                    Text(
                        textAlign: TextAlign.center,
                        'A network engineering course provides comprehensive education on designing, building, and managing communication networks. Covering topics like network protocols, routing, security, and troubleshooting, the course equips students with skills to create efficient and secure networks. Practical exercises and real-world scenarios enhance understanding of LANs, WANs, and cloud technologies, preparing students for careers in maintaining seamless data flow and connectivity across various devices and systems.',
                        style:
                            GoogleFonts.kanit(fontSize: 20, color: Colors.white)

                        //   fontWeight: FontWeight.bold,
                        ),
                    SizedBox(
                      height: 15.0,
                    ),
                    ElevatedButton(
                      onPressed: () {
                        _launchURL("https://bcas.lk/online-registration/");
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color.fromRGBO(12, 45, 112, 1.00),
                        // Background color
                      ),
                      child: Text('Apply Now',
                          style: GoogleFonts.kanit(fontSize: 20)),
                    ),
                  ],
                ),
              ),
              Container(
                // height: 220,
                width: 380,
                color: Color.fromRGBO(12, 45, 112, 1),
                padding: EdgeInsets.all(15),
                child: Text(
                  textAlign: TextAlign.center,
                  'Network Engineering Courses',
                  style: GoogleFonts.kanit(fontSize: 20, color: Colors.white),
                  maxLines: 25,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              SizedBox(
                height: 20.0,
              ),
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  height: 150,
                  width: 300,
                  color: Color.fromARGB(255, 243, 243, 243),
                  child: Column(
                    children: [
                      Text(
                          textAlign: TextAlign.center,
                          'Bsc (Hons) In Network Engineering',
                          style: GoogleFonts.kanit(
                            fontSize: 25,
                            color: Color.fromRGBO(0, 45, 112, 1.00),
                          )),
                      SizedBox(
                        height: 15.0,
                      ),
                      TextButton(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Icon(
                              Icons.arrow_circle_right_outlined,
                              size: 25,
                              color: Color.fromRGBO(131, 1, 14, 1),
                            ),
                            Text("Read More",
                                style: GoogleFonts.kanit(
                                  fontSize: 20,
                                  color: Color.fromRGBO(131, 1, 14, 1),
                                )),
                          ],
                        ),
                        onPressed: () {
                          _launchURL(
                              "https://bcas.lk/course/btec-hnd-in-networking-software/");
                        },
                      )
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 15.0,
              ),
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  height: 150,
                  width: 300,
                  color: Color.fromARGB(255, 243, 243, 243),
                  child: Column(
                    children: [
                      Text(
                          textAlign: TextAlign.center,
                          'Bsc (Hons) In Computer Systems & Networks',
                          style: GoogleFonts.kanit(
                            fontSize: 25,
                            color: Color.fromRGBO(0, 45, 112, 1.00),
                          )),
                      SizedBox(
                        height: 15.0,
                      ),
                      TextButton(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Icon(
                              Icons.arrow_circle_right_outlined,
                              size: 25,
                              color: Color.fromRGBO(131, 1, 14, 1),
                            ),
                            Text("Read More",
                                style: GoogleFonts.kanit(
                                  fontSize: 20,
                                  color: Color.fromRGBO(131, 1, 14, 1),
                                )),
                          ],
                        ),
                        onPressed: () {
                          _launchURL(
                              "https://bcas.lk/course/bsc-hons-in-computer-systems-networks/");
                        },
                      )
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 15.0,
              ),
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  height: 150,
                  width: 300,
                  color: Color.fromARGB(255, 243, 243, 243),
                  child: Column(
                    children: [
                      Text(
                          textAlign: TextAlign.center,
                          'BSc (Hons) in Cyber Security Management',
                          style: GoogleFonts.kanit(
                            fontSize: 25,
                            color: Color.fromRGBO(0, 45, 112, 1.00),
                          )),
                      SizedBox(
                        height: 15.0,
                      ),
                      TextButton(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Icon(
                              Icons.arrow_circle_right_outlined,
                              size: 25,
                              color: Color.fromRGBO(131, 1, 14, 1),
                            ),
                            Text("Read More",
                                style: GoogleFonts.kanit(
                                  fontSize: 20,
                                  color: Color.fromRGBO(131, 1, 14, 1),
                                )),
                          ],
                        ),
                        onPressed: () {
                          _launchURL(
                              "https://bcas.lk/course/bsc-hons-in-cyber-security-management/");
                        },
                      )
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 15.0,
              ),
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  height: 150,
                  width: 300,
                  color: Color.fromARGB(255, 243, 243, 243),
                  child: Column(
                    children: [
                      Text(
                          textAlign: TextAlign.center,
                          'International Foundation In Information Technology',
                          style: GoogleFonts.kanit(
                            fontSize: 25,
                            color: Color.fromRGBO(0, 45, 112, 1.00),
                          )),
                      SizedBox(
                        height: 15.0,
                      ),
                      TextButton(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Icon(
                              Icons.arrow_circle_right_outlined,
                              size: 25,
                              color: Color.fromRGBO(131, 1, 14, 1),
                            ),
                            Text("Read More",
                                style: GoogleFonts.kanit(
                                  fontSize: 20,
                                  color: Color.fromRGBO(131, 1, 14, 1),
                                )),
                          ],
                        ),
                        onPressed: () {
                          _launchURL(
                              "https://bcas.lk/course/international-foundation-in-information-technology/");
                        },
                      )
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 15.0,
              ),
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  height: 150,
                  width: 300,
                  color: Color.fromARGB(255, 243, 243, 243),
                  child: Column(
                    children: [
                      Text(
                          textAlign: TextAlign.center,
                          'BTEC HND In Networking Engineering',
                          style: GoogleFonts.kanit(
                              fontSize: 25,
                              color: Color.fromRGBO(0, 45, 112, 1.00))),
                      SizedBox(
                        height: 15.0,
                      ),
                      TextButton(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Icon(Icons.arrow_circle_right_outlined,
                                size: 25, color: Color.fromRGBO(131, 1, 14, 1)),
                            Text("Read More",
                                style: GoogleFonts.kanit(
                                    fontSize: 20,
                                    color: Color.fromRGBO(131, 1, 14, 1))),
                          ],
                        ),
                        onPressed: () {
                          _launchURL(
                              "https://bcas.lk/course/btec-hnd-in-networking-software/");
                        },
                      )
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 15.0,
              ),
              Container(
                height: 250,
                width: 450,
                color: Color.fromRGBO(45, 45, 45, 1.00),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      height: 250,
                      width: 300,
                      child: Image(image: AssetImage('assets/images/bcas.png')),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
      // body: CustomScrollView(slivers: [
      //   SliverAppBar(
      //     backgroundColor: Color.fromRGBO(170, 0, 10, 1.00),
      //     title: Text('NETWORKING'),
      //     centerTitle: true,
      //     expandedHeight: 100,
      //     floating: true,
      //     pinned: true,
      //     flexibleSpace: FlexibleSpaceBar(
      //       background: Container(
      //         color: Color.fromRGBO(12, 45, 112, 1.00),
      //       ),
      //     ),
      //   ),
      // ])
    );
  }
}
