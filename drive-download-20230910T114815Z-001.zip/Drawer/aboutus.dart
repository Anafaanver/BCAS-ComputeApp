import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Aboutus extends StatelessWidget {
  const Aboutus({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          flexibleSpace: Container(
            decoration: BoxDecoration(
                color: Color.fromRGBO(12, 45, 112, 1.00),
                borderRadius: BorderRadius.all(Radius.circular(00))),
          ),
          centerTitle: true,
          title: Text(
            'ABOUT US',
            style: GoogleFonts.kanit(fontSize: 25),
          ),
        ),
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Center(
            child: Column(
              children: [
                SizedBox(
                  height: 10.0,
                ),
                SizedBox(
                  height: 20.0,
                ),
                Container(
                  height: 220,
                  width: 380,
                  color: Color.fromRGBO(131, 1, 14, 1),
                  padding: EdgeInsets.all(15),
                  child: Text(
                    textAlign: TextAlign.center,
                    'Our institution provides students with the unique combination of character development and academic vision needed to pursue a career. BCAS takes pride on providing students with the skills and experience they need to succeed in todays workplace by working closely with industry partners to ensure they are well-prepared with great opportunities to learn and grow. BCAS is the perfect place to start your journey toward a successful career.',
                    style: GoogleFonts.kanit(fontSize: 15, color: Colors.white),
                    maxLines: 25,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Divider(
                  height: 100,
                  color: Color.fromRGBO(131, 1, 14, 1),
                  thickness: 1.5,
                  indent: 10,
                  endIndent: 10,
                ),
                Container(
                  // height: 220,
                  width: 380,
                  color: Color.fromRGBO(12, 45, 112, 1),
                  padding: EdgeInsets.all(15),
                  child: Text(
                    textAlign: TextAlign.center,
                    'Chairman’s Message',
                    style: GoogleFonts.kanit(fontSize: 20, color: Colors.white),
                    maxLines: 25,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Container(
                  height: 200,
                  color: const Color.fromARGB(255, 255, 255, 255),
                  child:
                      Image(image: AssetImage('assets/images/thiyagaraja.png')),
                ),
                SizedBox(
                  height: 10.0,
                ),
                Text(
                  'Mr. Rajendra Theagarajah',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                ),
                Text(
                  'Non-Executive Chairman',
                  style: TextStyle(fontSize: 15),
                ),
                Text(
                  'BCAS Campus, Sri Lanka.',
                  style: TextStyle(fontSize: 15),
                ),
                SizedBox(
                  height: 11.0,
                ),
                Container(
                  height: 380,
                  width: 380,
                  color: Color.fromRGBO(131, 1, 14, 1),
                  padding: EdgeInsets.all(15),
                  child: Text(
                    textAlign: TextAlign.center,
                    '“Knowledge is Power”, has under pinned our efforts in providing high quality education for developing students with ethical and moral values, while enhancing their employability, leadership qualities, research culture and innovative skills. At BCAS we offer a spectrum of market-relevant programs delivered in a conducive and dynamic learning environment that nurtures students with the knowledge and skills necessary to succeed in their chosen careers. Additionally, our highly experienced and qualified faculty members, continuously engage in the maintenance and enhancement of student-centric learning environment through innovative delivery methodologies. Our admissions team eagerly looks forward to engage with you, whether you are a prospective student, parent, Guardian or employer, and help clarify any matter which will help you decide on a course that best fits your aspiration.',
                    style: GoogleFonts.kanit(fontSize: 15, color: Colors.white),
                    maxLines: 25,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Divider(
                  height: 100,
                  color: Color.fromRGBO(131, 1, 14, 1),
                  thickness: 1.5,
                  indent: 10,
                  endIndent: 10,
                ),
                Container(
                  // height: 220,
                  width: 380,
                  color: Color.fromRGBO(12, 45, 112, 1),
                  padding: EdgeInsets.all(15),
                  child: Text(
                    textAlign: TextAlign.center,
                    'CEO’s Message',
                    style: GoogleFonts.kanit(fontSize: 20, color: Colors.white),
                    maxLines: 25,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                SizedBox(
                  height: 20.0,
                ),
                Container(
                  height: 200,
                  color: const Color.fromARGB(255, 255, 255, 255),
                  child: Image(image: AssetImage('assets/images/ceo.png')),
                ),
                SizedBox(
                  height: 10.0,
                ),
                Text(
                  'Dr. Susil Kumara Silva',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                ),
                Text(
                  'CEO & Executive Director',
                  style: TextStyle(fontSize: 15),
                ),
                Text(
                  'BCAS Campus',
                  style: TextStyle(fontSize: 15),
                ),
                SizedBox(
                  height: 11.0,
                ),
                Container(
                  height: 425,
                  width: 380,
                  color: Color.fromRGBO(131, 1, 14, 1),
                  padding: EdgeInsets.all(15),
                  child: Text(
                    textAlign: TextAlign.center,
                    'British College of Applied Studies (BCAS) is a premium higher education institution in Sri Lanka with 23+ years of trusted excellence. BCAS is in the process of rapidly expanding higher education options for Sri Lankan youth with wide range of degree options in affiliation with top-ranked Universities in the UK. BCAS focuses on delivering real world, relevant business and technological programmes with a balance of theory and applied learning, providing students with both strategic and soft interpersonal skills. World is at the forefront of modern as well as unpredictable challenges. Focus on globalization, technology breakthrough and innovation alone cannot find answers for the current issues.  Graduates are nowadays required to be more systemic and sensitive to ecological factors than ever before underpinning Triple Bottom Line (TBL). As the senior management of BCAS, we are ambitiously looking forward for a long-lasting, mutually beneficial partnership in achieving the common goals in the locally and internationally thriving private higher education sector.',
                    style: GoogleFonts.kanit(fontSize: 15, color: Colors.white),
                    maxLines: 25,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                SizedBox(
                  height: 11.0,
                ),
                Container(
                  height: 250,
                  width: 450,
                  color: Color.fromRGBO(45, 45, 45, 1.00),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        height: 250,
                        width: 300,
                        child:
                            Image(image: AssetImage('assets/images/bcas.png')),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ));
  }
}
