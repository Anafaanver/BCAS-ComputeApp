import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Location extends StatelessWidget {
  const Location({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // extendBodyBehindAppBar: true,
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: BoxDecoration(
              color: Color.fromRGBO(12, 45, 112, 1.00),
              borderRadius: BorderRadius.all(Radius.circular(00))),
        ),
        centerTitle: true,
        title: Text(
          'LOCATION',
          style: GoogleFonts.kanit(fontSize: 25),
        ),
      ),
      backgroundColor: Color.fromARGB(255, 255, 255, 255),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 30.0,
            ),
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Container(
                height: 150,
                width: 250,
                color: const Color.fromARGB(255, 243, 243, 243),
                child: Column(
                  children: [
                    Text('COLOMBO',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.kanit(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Color.fromRGBO(131, 1, 14, 1),
                        )),
                    Text('No: 356, Galle Road,',
                        style: GoogleFonts.kanit(
                          fontSize: 22,
                          color: Color.fromRGBO(131, 1, 14, 1),
                        )),
                    Text('Colombo 03, Sri Lanka.',
                        style: GoogleFonts.kanit(
                          fontSize: 22,
                          color: Color.fromRGBO(131, 1, 14, 1),
                        )),
                    Text('+94 778 444 555',
                        style: GoogleFonts.kanit(
                          fontSize: 22,
                          color: Color.fromRGBO(131, 1, 14, 1),
                        )),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 30.0,
            ),
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  height: 150,
                  width: 250,
                  color: const Color.fromARGB(255, 243, 243, 243),
                  child: Column(
                    children: [
                      Text('KANDY',
                          textAlign: TextAlign.center,
                          style: GoogleFonts.kanit(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Color.fromRGBO(131, 1, 14, 1),
                          )),
                      Text('No: 344, Peradeniya Road,',
                          style: GoogleFonts.kanit(
                            fontSize: 22,
                            color: Color.fromRGBO(131, 1, 14, 1),
                          )),
                      Text('Kandy, Sri Lanka.',
                          style: GoogleFonts.kanit(
                            fontSize: 22,
                            color: Color.fromRGBO(131, 1, 14, 1),
                          )),
                      Text('+94 812 224 731',
                          style: GoogleFonts.kanit(
                            fontSize: 22,
                            color: Color.fromRGBO(131, 1, 14, 1),
                          )),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 30.0,
            ),
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  height: 150,
                  width: 250,
                  color: const Color.fromARGB(255, 243, 243, 243),
                  child: Column(
                    children: [
                      Text('JAFFNA',
                          textAlign: TextAlign.center,
                          style: GoogleFonts.kanit(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Color.fromRGBO(131, 1, 14, 1),
                          )),
                      Text('No: 16, Point Pedro Road,',
                          style: GoogleFonts.kanit(
                            fontSize: 22,
                            color: Color.fromRGBO(131, 1, 14, 1),
                          )),
                      Text('Jaffna, Sri Lanka.',
                          style: GoogleFonts.kanit(
                            fontSize: 22,
                            color: Color.fromRGBO(131, 1, 14, 1),
                          )),
                      Text('+94 212 219 910',
                          style: GoogleFonts.kanit(
                            fontSize: 22,
                            color: Color.fromRGBO(131, 1, 14, 1),
                          )),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 30.0,
            ),
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  height: 150,
                  width: 250,
                  color: Color.fromARGB(255, 243, 243, 243),
                  child: Column(
                    children: [
                      Text('KALMUNAI',
                          textAlign: TextAlign.center,
                          style: GoogleFonts.kanit(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Color.fromRGBO(131, 1, 14, 1),
                          )),
                      Text('No: 392/1, Main Street,',
                          style: GoogleFonts.kanit(
                            fontSize: 22,
                            color: Color.fromRGBO(131, 1, 14, 1),
                          )),
                      Text('Kalmunai, Sri Lanka.',
                          style: GoogleFonts.kanit(
                            fontSize: 22,
                            color: Color.fromRGBO(131, 1, 14, 1),
                          )),
                      Text('+94 672 226 899',
                          style: GoogleFonts.kanit(
                            fontSize: 22,
                            color: Color.fromRGBO(131, 1, 14, 1),
                          )),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 30.0,
            ),
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  height: 150,
                  width: 250,
                  color: const Color.fromARGB(255, 243, 243, 243),
                  child: Column(
                    children: [
                      Text('GALLE',
                          textAlign: TextAlign.center,
                          style: GoogleFonts.kanit(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Color.fromRGBO(131, 1, 14, 1),
                          )),
                      Text('No: 106, Colombo Rd,',
                          style: GoogleFonts.kanit(
                            fontSize: 22,
                            color: Color.fromRGBO(131, 1, 14, 1),
                          )),
                      Text('Kaluwella, Galle, Sri Lanka.',
                          style: GoogleFonts.kanit(
                            fontSize: 22,
                            color: Color.fromRGBO(131, 1, 14, 1),
                          )),
                      Text('+94 77 685 8441',
                          style: GoogleFonts.kanit(
                            fontSize: 22,
                            color: Color.fromRGBO(131, 1, 14, 1),
                          )),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 30.0,
            ),
            Container(
              height: 250,
              width: 450,
              color: Color.fromRGBO(45, 45, 45, 1.00),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    height: 250,
                    width: 300,
                    child: Image(image: AssetImage('assets/images/bcas.png')),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
