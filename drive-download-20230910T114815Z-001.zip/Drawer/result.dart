// import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:google_fonts/google_fonts.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  runApp(const Results());
}

class Results extends StatelessWidget {
  const Results({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: BoxDecoration(
              color: Color.fromRGBO(12, 45, 112, 1.00),
              borderRadius: BorderRadius.all(Radius.circular(00))),
        ),
        centerTitle: true,
        title: Text(
          'RESULTS',
          style: GoogleFonts.kanit(fontSize: 25),
        ),
      ),
    );
  }
}
